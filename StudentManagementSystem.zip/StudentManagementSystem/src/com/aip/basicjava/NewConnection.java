package com.aip.basicjava;
 import java.sql.*;
 
public class NewConnection {
public static void insertdata(String addno,String stname, String DOB, String gender,String stclass,String fname,String mname,String contact,String address ) {
	try {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
		String query="insert into Studentrecord values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement ptmt=con.prepareStatement(query);
		ptmt.setString(1, addno);
		ptmt.setString(2,  stname);
		ptmt.setString(3, DOB);
		ptmt.setString(4, gender);
		ptmt.setString(5, stclass);
		ptmt.setString(6, fname);
		ptmt.setString(7, mname);
		ptmt.setString(8, contact);
		ptmt.setString(9, address);
		ptmt.executeUpdate();
		con.close();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}
public static void updatedata(String addno,String stname, String DOB, String gender,String stclass,String fname,String mname,String contact,String address ) {
	try {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
		String query="update Studentrecord set stname=?,DOB=?,gender=?,stclass=?,fname=?,mname=?,contact=?,address=? where addno=?";
		PreparedStatement ptmt=con.prepareStatement(query);
		
		ptmt.setString(1,  stname);
		ptmt.setString(2, DOB);
		ptmt.setString(3, gender);
		ptmt.setString(4, stclass);
		ptmt.setString(5, fname);
		ptmt.setString(6, mname);
		ptmt.setString(7, contact);
		ptmt.setString(8, address);
		ptmt.setString(9, addno);
		ptmt.executeUpdate();
		con.close();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	}

public static void deleteData(String addmNo)
{
	try {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123");
		String query="delete from Studentrecord where addno=?";
		PreparedStatement ptmt=con.prepareStatement(query);
		ptmt.setString(1, addmNo);
		ptmt.executeUpdate();
		con.close();
	}
	catch(Exception e) {
		e.printStackTrace();
	}
}
}
