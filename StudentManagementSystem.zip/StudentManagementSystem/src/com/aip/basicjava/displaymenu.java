package com.aip.basicjava;

import java.awt.EventQueue;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JTabbedPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class displaymenu {

	private JFrame frame;
	private JTextField nameinput;
	private JTextField dobinput;
	private JTextField genderinput;
	private JTextField classinput;
	private JTextField contactinput;
	private JTextField adminput;
	private JTextField fnameinput;
	private JTextField mnameinput;
	private JTextField addressinput;
	private JTextField newnameinput;
	private JTextField newdobinput;
	private JTextField newgenderinput;
	private JTextField newclassinput;
	private JTextField newcontactinput;
	private JTextField newadminput;
	private JTextField newfnameinput;
	private JTextField newmnameinput;
	private JTextField newaddressinput;
	private JTextField searchAddno;
	private JTable displaytable;
	private JTextField deleteInput;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					displaymenu window = new displaymenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public displaymenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1161, 636);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBackground(new Color(0, 0, 0));
		frame.getContentPane().add(layeredPane, BorderLayout.CENTER);
		
		JPanel createPanel = new JPanel();
		createPanel.setBackground(new Color(135, 206, 250));
		layeredPane.setLayer(createPanel, 0);
		createPanel.setBounds(286, 10, 861, 579);
		layeredPane.add(createPanel);
		createPanel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setBounds(73, 112, 56, 24);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		createPanel.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("ADDMISSION FORM");
		lblNewLabel.setBounds(282, 39, 242, 30);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 25));
		createPanel.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("DOB:");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_2.setBounds(73, 187, 56, 21);
		createPanel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Gender:");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_3.setBounds(73, 263, 70, 21);
		createPanel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_8 = new JLabel("Class:");
		lblNewLabel_8.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_8.setBounds(81, 351, 62, 16);
		createPanel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Contact:");
		lblNewLabel_9.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_9.setBounds(81, 451, 86, 21);
		createPanel.add(lblNewLabel_9);
		
		JLabel lblNewLabel_5 = new JLabel("Addmisson no:");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_5.setBounds(495, 112, 133, 24);
		createPanel.add(lblNewLabel_5);
		
		JLabel lblNewLabel_7 = new JLabel("Father's Name:");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_7.setBounds(495, 187, 133, 21);
		createPanel.add(lblNewLabel_7);
		
		JLabel lblNewLabel_6 = new JLabel("Mother's Name:");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_6.setBounds(495, 263, 148, 17);
		createPanel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_4 = new JLabel("Address:");
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_4.setBounds(495, 353, 78, 13);
		createPanel.add(lblNewLabel_4);
		
		JButton btnNewButton_5 = new JButton("Submit");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String addno=adminput.getText();
				String stname=nameinput.getText();
				String DOB=dobinput.getText();
				String gender=genderinput.getText();
				String stclass=classinput.getText();
				String fname=fnameinput.getText();
				String mname=mnameinput.getText();
				String contact=contactinput.getText();
				String address=addressinput.getText();
				NewConnection.insertdata(addno, stname, DOB, gender, stclass, fname, mname, contact, address);
			}
		});
		btnNewButton_5.setForeground(new Color(0, 0, 0));
		btnNewButton_5.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5.setBackground(Color.LIGHT_GRAY);
		btnNewButton_5.setBounds(323, 517, 107, 30);
		createPanel.add(btnNewButton_5);
		
		nameinput = new JTextField();
		nameinput.setColumns(10);
		nameinput.setBounds(189, 117, 96, 19);
		createPanel.add(nameinput);
		
		dobinput = new JTextField();
		dobinput.setColumns(10);
		dobinput.setBounds(189, 190, 96, 19);
		createPanel.add(dobinput);
		
		genderinput = new JTextField();
		genderinput.setColumns(10);
		genderinput.setBounds(189, 266, 96, 19);
		createPanel.add(genderinput);
		
		classinput = new JTextField();
		classinput.setColumns(10);
		classinput.setBounds(189, 352, 96, 19);
		createPanel.add(classinput);
		
		contactinput = new JTextField();
		contactinput.setColumns(10);
		contactinput.setBounds(189, 454, 96, 19);
		createPanel.add(contactinput);
		
		adminput = new JTextField();
		adminput.setColumns(10);
		adminput.setBounds(662, 117, 96, 19);
		createPanel.add(adminput);
		
		fnameinput = new JTextField();
		fnameinput.setColumns(10);
		fnameinput.setBounds(662, 190, 96, 19);
		createPanel.add(fnameinput);
		
		mnameinput = new JTextField();
		mnameinput.setColumns(10);
		mnameinput.setBounds(662, 266, 96, 19);
		createPanel.add(mnameinput);
		
		addressinput = new JTextField();
		addressinput.setColumns(10);
		addressinput.setBounds(662, 352, 96, 19);
		createPanel.add(addressinput);
		
		JButton btnNewButton_6 = new JButton("Reset");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminput.setText("");
				nameinput.setText("");
				dobinput.setText("");
				genderinput.setText("");
				classinput.setText("");
				fnameinput.setText("");
				mnameinput.setText("");
				contactinput.setText("");
				addressinput.setText("");
				
			}
		});
		btnNewButton_6.setBackground(Color.LIGHT_GRAY);
		btnNewButton_6.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_6.setBounds(481, 517, 96, 31);
		createPanel.add(btnNewButton_6);
		
		JPanel modifyPanel = new JPanel();
		layeredPane.setLayer(modifyPanel, 0);
		modifyPanel.setBackground(Color.CYAN);
		modifyPanel.setLayout(null);
		modifyPanel.setBounds(284, 11, 861, 579);
		layeredPane.add(modifyPanel);
		
		JLabel lblNewLabel_1_1 = new JLabel("Name:");
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(73, 203, 56, 24);
		modifyPanel.add(lblNewLabel_1_1);
		
		JLabel lblModifyStudentRecord = new JLabel("MODIFY STUDENT RECORD");
		lblModifyStudentRecord.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblModifyStudentRecord.setBounds(237, 23, 352, 30);
		modifyPanel.add(lblModifyStudentRecord);
		
		JLabel lblNewLabel_2_1 = new JLabel("DOB:");
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_2_1.setBounds(73, 267, 56, 21);
		modifyPanel.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Gender:");
		lblNewLabel_3_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_3_1.setBounds(73, 326, 70, 21);
		modifyPanel.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_8_1 = new JLabel("Class:");
		lblNewLabel_8_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_8_1.setBounds(73, 393, 62, 16);
		modifyPanel.add(lblNewLabel_8_1);
		
		JLabel lblNewLabel_9_1 = new JLabel("Contact:");
		lblNewLabel_9_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_9_1.setBounds(73, 451, 86, 21);
		modifyPanel.add(lblNewLabel_9_1);
		
		JLabel lblNewLabel_5_1 = new JLabel("Addmisson no:");
		lblNewLabel_5_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_5_1.setBounds(51, 85, 133, 24);
		modifyPanel.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_7_1 = new JLabel("Father's Name:");
		lblNewLabel_7_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_7_1.setBounds(496, 205, 133, 21);
		modifyPanel.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_6_1 = new JLabel("Mother's Name:");
		lblNewLabel_6_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_6_1.setBounds(496, 271, 148, 13);
		modifyPanel.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Address:");
		lblNewLabel_4_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_4_1.setBounds(496, 330, 78, 13);
		modifyPanel.add(lblNewLabel_4_1);
		
		
		
		newnameinput = new JTextField();
		newnameinput.setColumns(10);
		newnameinput.setBounds(189, 206, 96, 21);
		modifyPanel.add(newnameinput);
		
		newdobinput = new JTextField();
		newdobinput.setColumns(10);
		newdobinput.setBounds(189, 266, 96, 19);
		modifyPanel.add(newdobinput);
		
		newgenderinput = new JTextField();
		newgenderinput.setColumns(10);
		newgenderinput.setBounds(189, 329, 96, 19);
		modifyPanel.add(newgenderinput);
		
		newclassinput = new JTextField();
		newclassinput.setColumns(10);
		newclassinput.setBounds(189, 394, 96, 19);
		modifyPanel.add(newclassinput);
		
		newcontactinput = new JTextField();
		newcontactinput.setColumns(10);
		newcontactinput.setBounds(189, 454, 96, 19);
		modifyPanel.add(newcontactinput);
		
		newadminput = new JTextField();
		newadminput.setColumns(10);
		newadminput.setBounds(189, 90, 96, 19);
		modifyPanel.add(newadminput);
		
		newfnameinput = new JTextField();
		newfnameinput.setColumns(10);
		newfnameinput.setBounds(662, 208, 96, 19);
		modifyPanel.add(newfnameinput);
		
		newmnameinput = new JTextField();
		newmnameinput.setColumns(10);
		newmnameinput.setBounds(662, 270, 96, 19);
		modifyPanel.add(newmnameinput);
		
		newaddressinput = new JTextField();
		newaddressinput.setColumns(10);
		newaddressinput.setBounds(662, 329, 96, 19);
		modifyPanel.add(newaddressinput);
		
		JButton btnNewButton_5_1 = new JButton("UPDATE");
		btnNewButton_5_1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				String addno=newadminput.getText();
				String stname=newnameinput.getText();
				String DOB=newdobinput.getText();
				String gender=newgenderinput.getText();
				String stclass=newclassinput.getText();
				String fname=newfnameinput.getText();
				String mname=newmnameinput.getText();
				String contact=newcontactinput.getText();
				String address=newaddressinput.getText();
				NewConnection.updatedata(addno, stname, DOB, gender, stclass, fname, mname, contact, address);
			}
		});
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5_1.setForeground(Color.BLACK);
		btnNewButton_5_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_5_1.setBounds(279, 496, 127, 30);
		modifyPanel.add(btnNewButton_5_1);
		
		JPanel searchPanel = new JPanel();
		searchPanel.setBounds(286, 10, 861, 579);
		layeredPane.add(searchPanel);
		layeredPane.setLayer(searchPanel, 1);
		searchPanel.setLayout(null);
		searchPanel.setBackground(new Color(224, 255, 255));
		
		JLabel lblSearchStudentRecord = new JLabel("SEARCH STUDENT RECORD");
		lblSearchStudentRecord.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblSearchStudentRecord.setBounds(237, 23, 352, 30);
		searchPanel.add(lblSearchStudentRecord);
		
		JLabel lblNewLabel_5_1_1 = new JLabel("Addmisson no:");
		lblNewLabel_5_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_5_1_1.setBounds(61, 90, 168, 49);
		searchPanel.add(lblNewLabel_5_1_1);
		
		JButton btnNewButton_5_1_1 = new JButton("SEARCH");
		btnNewButton_5_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displaytable.setModel(new DefaultTableModel(null, new String[]{"ID","Name","D.O.B","Gender","Class","Father Name","Mother Name","Contact no.","Address"}));
				try {
					String searchAddmNoInput = searchAddno.getText();
					// Load the drivers
					Class.forName("oracle.jdbc.OracleDriver");
					// connection establish
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123");
					String query = "select * from Studentrecord where addNo=?";
					PreparedStatement prst = con.prepareStatement(query);
					prst.setString(1, searchAddmNoInput);
					ResultSet rs = prst.executeQuery();
					while(rs.next())
					{
						String tbData[] = {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)};
						DefaultTableModel tbModel = (DefaultTableModel)displaytable.getModel();
						tbModel.addRow(tbData);
					}
					con.close();
				} 
				catch (Exception ex) {
					// TODO: handle exception
					ex.printStackTrace();
				}
			}
		});
		btnNewButton_5_1_1.setForeground(new Color(0, 0, 0));
		btnNewButton_5_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_5_1_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_5_1_1.setBounds(631, 101, 127, 30);
		searchPanel.add(btnNewButton_5_1_1);
		
		searchAddno = new JTextField();
		searchAddno.setColumns(10);
		searchAddno.setBounds(258, 98, 112, 30);
		searchPanel.add(searchAddno);
		
		JButton btnNewButton = new JButton("Display All");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				displaytable.setModel(new DefaultTableModel(null, new String[]{"ID","Name","D.O.B","Gender","Class","Father Name","Mother Name","Contact no.","Address"}));
				try {
					// Load the drivers
					Class.forName("oracle.jdbc.OracleDriver");
					// connection establish
					Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123");
					String query = "select * from Studentrecord order by addno";
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery(query);
					while(rs.next())
					{
						String tbData[] = {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)};
						DefaultTableModel tbModel = (DefaultTableModel)displaytable.getModel();
						tbModel.addRow(tbData);
					}
					con.close();
				} 
				catch (Exception ex) {
					// TODO: handle exception
					ex.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton.setBounds(315, 462, 168, 33);
		searchPanel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(44, 200, 753, 205);
		searchPanel.add(scrollPane);
		
		displaytable = new JTable();
		displaytable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		scrollPane.setViewportView(displaytable);
		
		JPanel deletePanel = new JPanel();
		layeredPane.setLayer(deletePanel, 0);
		deletePanel.setLayout(null);
		deletePanel.setBackground(new Color(255, 165, 0));
		deletePanel.setBounds(285, 10, 861, 579);
		layeredPane.add(deletePanel);
		
		JLabel lblDeleteStudentRecord = new JLabel("DELETE STUDENT RECORD");
		lblDeleteStudentRecord.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblDeleteStudentRecord.setBounds(237, 23, 352, 30);
		deletePanel.add(lblDeleteStudentRecord);
		
		JLabel lblNewLabel_5_1_1_1 = new JLabel("Addmisson no:");
		lblNewLabel_5_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 25));
		lblNewLabel_5_1_1_1.setBounds(245, 212, 168, 49);
		deletePanel.add(lblNewLabel_5_1_1_1);
		
		deleteInput = new JTextField();
		deleteInput.setColumns(10);
		deleteInput.setBounds(429, 226, 112, 30);
		deletePanel.add(deleteInput);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String deleteAddNo = deleteInput.getText();
				NewConnection.deleteData(deleteAddNo);
			}
		});
		btnDelete.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnDelete.setBounds(352, 462, 131, 33);
		deletePanel.add(btnDelete);
		
		JButton btnNewButton_7 = new JButton("RESET");
		btnNewButton_7.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				newadminput.setText("");
				newnameinput.setText("");
				newdobinput.setText("");
				newgenderinput.setText("");
				newclassinput.setText("");
				newfnameinput.setText("");
				newmnameinput.setText("");
				newcontactinput.setText("");
				newaddressinput.setText("");
			}
		});
		btnNewButton_7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnNewButton_7.setBounds(431, 496, 127, 28);
		modifyPanel.add(btnNewButton_7);
		
		JButton Create = new JButton("Create Student Record");
		Create.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		layeredPane.setLayer(Create, 0);
		Create.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				createPanel.setVisible(true);
				modifyPanel.setVisible(false);
				deletePanel.setVisible(false);
				searchPanel.setVisible(false);
			}
		});
		Create.setBackground(new Color(255, 215, 0));
		Create.setFont(new Font("Times New Roman", Font.BOLD, 15));
		Create.setBounds(39, 224, 183, 62);
		layeredPane.add(Create);
		
		JButton btnNewButton_1 = new JButton("Search Student Record");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createPanel.setVisible(false);
				modifyPanel.setVisible(false);
				deletePanel.setVisible(false);
				searchPanel.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(new Color(255, 215, 0));
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_1.setBounds(39, 296, 183, 60);
		layeredPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Modify Student Record");
		btnNewButton_2.setBackground(new Color(255, 215, 0));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createPanel.setVisible(false);
				modifyPanel.setVisible(true);
				deletePanel.setVisible(false);
				searchPanel.setVisible(false);
			}
		});
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_2.setBounds(39, 366, 185, 67);
		layeredPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete Student Record");
		btnNewButton_3.setBackground(new Color(255, 215, 0));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createPanel.setVisible(false);
				modifyPanel.setVisible(false);
				deletePanel.setVisible(true);
				searchPanel.setVisible(false);
			}
		});
		btnNewButton_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_3.setBounds(39, 443, 183, 62);
		layeredPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Exit");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_4.setBackground(new Color(255, 215, 0));
		btnNewButton_4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnNewButton_4.setBounds(39, 515, 183, 60);
		layeredPane.add(btnNewButton_4);
		
		JLabel lblNewLabel_10 = new JLabel("STUDENT");
		lblNewLabel_10.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_10.setBounds(62, 34, 160, 27);
		layeredPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("MANAGEMENT");
		lblNewLabel_11.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_11.setBounds(22, 71, 241, 38);
		layeredPane.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("SYSTEM");
		lblNewLabel_12.setFont(new Font("Times New Roman", Font.BOLD, 30));
		lblNewLabel_12.setBounds(62, 119, 143, 27);
		layeredPane.add(lblNewLabel_12);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 0));
		panel.setBounds(10, 10, 275, 579);
		layeredPane.add(panel);
		
		
	}
}
